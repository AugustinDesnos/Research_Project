# Installation

- Install Julia
- Install the Python `juliacall` package (`pip3 install juliacall`)
- Install the required Julia packages
    - From Julia Package REPL (press `]` in Julia REPL to access it)
    ```julia
    activate CasualtyRisk
    instantiate
    ```
    - From Python
    ```python
    from juliacall import Pkg as jlPkg
    jlPkg.activate("CasualtyRisk") # Replace with relative path to the CasualtyRisk folder
    jlPkg.instantiate()
    ```

# Usage in Python

```python
from juliacall import Main as jl
from juliacall import Pkg as jlPkg

jlPkg.activate("CasualtyRisk") # Replace with relative path to the CasualtyRisk folder
jl.seval("using CasualtyRisk")

# Refer to compute_casualty_risk() docstring in CasualtyRisk.jl
jl.compute_casualty_risk(cells, mean, cov, inc)
```