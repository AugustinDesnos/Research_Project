module CasualtyRisk

using StaticArrays, HCubature, LinearAlgebra

export compute_casualty_risk

const SUM_CUT = 5

"""
2D Gaussian Probability Density Function
"""
struct GaussianPDF2D
    norm::Float64
    μ::SVector{2,Float64}
    Σ⁻¹::SMatrix{2,2,Float64,4}
    # Precompute the fixed quantities in the PDF
    GaussianPDF2D(μ::SVector{2,Float64}, Σ::SMatrix{2,2,Float64,4}) = new(
        1 / (2π * sqrt(det(Σ))),
        μ, inv(Σ)
    )
end

function (pdf::GaussianPDF2D)(x)
    dx = x - pdf.μ
    return pdf.norm * exp(-0.5 * dx' * pdf.Σ⁻¹ * dx)
end

"""
Compute the probability density of impacting the given coordinates
- `Φ`: Latitude
- `λ`: Longitude
- `Φ`: Inclination
- `N`: Sum truncation length
- `pdf`: Probability density function `pdf([Λ,α])`
"""
function impact_density(Φ, λ, i, N::Int, pdf)
    sin_λ, cos_λ = sincos(λ)
    sin_i, cos_i = sincos(i)

    α0 = asin(sin(Φ) / sin_i)
    α1 = π - α0
    sin_α0, cos_α0 = sincos(α0)
    sin_α1 = sin_α0
    cos_α1 = -cos_α0

    num = cos_α0 * sin_λ - cos_i * sin_α0 * cos_λ
    den = cos_α0 * cos_λ + cos_i * sin_α0 * sin_λ
    Λ0 = atan(num, den)
    num = cos_α1 * sin_λ - cos_i * sin_α1 * cos_λ
    den = cos_α1 * cos_λ + cos_i * sin_α1 * sin_λ
    Λ1 = atan(num, den)

    pdf_sum = 0.0
    for n in -N:N
        for m in -N:N
            pdf_sum += pdf(SA[Λ0+2π*m, α0+2π*n])
            pdf_sum += pdf(SA[Λ1+2π*m, α1+2π*n])
        end
    end
    return pdf_sum
end

"""
Compute the probability of impacting the defined cell
"""
function impact_probability(Φmin, Φmax, λmin, λmax, i, pdf, tolerance)
    f(u) = impact_density(u[1], u[2], i, SUM_CUT, pdf)
    return hcubature(f, SA[Φmin, λmin], SA[Φmax, λmax], rtol=tolerance)[1]
end

"""
Compute the casualty risk in the cell
- `cell`: Cell definition `((lat_min, lat_max, lon_min, lon_max), pop)`
- `i`: Inclination
- `pdf`: Probability density function
"""
function cell_casualty_risk(cell, i, pdf, tolerance)
    ((Φmin, Φmax, λmin, λmax), pop) = cell
    sin_Φmin = sin(Φmin)
    sin_Φmax = sin(Φmax)
    sin_i = sin(i)
    if pop == 0.0 || sin_Φmin >= sin_i || sin_Φmax <= -sin_i
        # Cell is uninhabitated or outside the reachable latitudes
        return 0.0
    else
        # Restrict latitude range to reachable values according to inclination
        if sin_Φmin < -sin_i
            Φmin = asin(-sin_i)
        end
        if sin_Φmax > sin_i
            Φmax = asin(sin_i)
        end
        # Compute impact probability
        cell_proba = impact_probability(Φmin, Φmax, λmin, λmax, i, pdf, tolerance)
        # Compute casualty risk
        pop_density = pop / (6371^2 * (sin(Φmax) - sin(Φmin)) * (λmax - λmin)*1e6) # TODO there's probably a more accurate formula
        return pop_density * cell_proba
    end
end

"""
Compute the casualty risk over all the given cells
- `cells`: List of cells, each cell is a tuple `((lat_min, lat_max, lon_min, lon_max), pop)`
- `mean`: Mean vector of the `[Λ, α]` gaussian distribution
- `cov`: Covariance matrix of the `[Λ, α]` gaussian distribution
- `inc`: Inclination
- `casualty_area`: (optional) Casualty area of surviving debris
"""
function compute_casualty_risk(cells, mean, cov, inc, casualty_area=1.0, tolerance = 1e-8)
    pdf = GaussianPDF2D(SVector{2}(mean), SMatrix{2,2}(cov))
    total_risk = 0.0
    for index in eachindex(cells)
        total_risk += cell_casualty_risk(cells[index], inc, pdf, tolerance)
    end
    return casualty_area * total_risk
end

end # module RiskIntegrator